package vn.chungdt.hola_shop_be;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HolaShopBeApplication {

	public static void main(String[] args) {
		SpringApplication.run(HolaShopBeApplication.class, args);
	}

}

package vn.chungdt.hola_shop_be;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HolaShopBeApplicationTests {

	@Test
	void contextLoads() {
	}

}
